package regresionPolinomial;

import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;

import java.util.Arrays;

public class RegresionPolinomial extends Agent {

    protected void setup() {
        System.out.println("Agent " + getLocalName() + " started.");

        // Registrar el servicio de regresión polinomial en el Directory Facilitator
        registrarServicio("PolyRAgent", "regresion-polinomial");

        // Comportamiento para recibir el dataset del DataSetAgent
        addBehaviour(new ReceiveDataSet());
    }

    protected void takeDown() {
        // Deregistrar el servicio al terminar el agente
        deregistrarServicio();
        System.out.println("Agent " + getLocalName() + " terminating.");
    }

    private void registrarServicio(String agentName, String serviceType) {
        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(getAID());
        ServiceDescription sd = new ServiceDescription();
        sd.setType(serviceType);
        sd.setName(agentName);
        dfd.addServices(sd);
        try {
            DFService.register(this, dfd);
            System.out.println("Service registered: " + agentName + " - " + serviceType);
        } catch (FIPAException fe) {
            fe.printStackTrace();
        }
    }

    private void deregistrarServicio() {
        try {
            DFService.deregister(this);
        } catch (FIPAException fe) {
            fe.printStackTrace();
        }
    }

    private class ReceiveDataSet extends CyclicBehaviour {
        public void action() {
            MessageTemplate mt = MessageTemplate.MatchPerformative(ACLMessage.REQUEST);
            ACLMessage msg = myAgent.receive(mt);
            if (msg != null) {
                String response = msg.getContent(); // Supongamos que el mensaje contiene el dataset
                String[] parts = response.split(";");

                // Extraer los datos del dataset
                String[] xValues = parts[0].replace("x:", "").split(",");
                String[] yValues = parts[1].replace("y:", "").split(",");

                // Convertir los datos a un formato adecuado para tu código de regresión polinomial
                double[] xData = Arrays.stream(xValues).mapToDouble(Double::parseDouble).toArray();
                double[] yData = Arrays.stream(yValues).mapToDouble(Double::parseDouble).toArray();

                // Crear el objeto para la regresión polinomial (grado 3 por defecto)
                PolinomialRegression polyReg = new PolinomialRegression(xData, yData, 3); // Grado del polinomio

                // Realizar cálculos y operaciones de la regresión polinomial
                polyReg.fit();
                polyReg.printRegEquation();
                polyReg.predict(6); // Ejemplo de predicción para x = 6

                // Otros pasos de tu lógica después de la regresión polinomial
            } else {
                block();
            }
        }
    }
}

class PolinomialRegression {
    private final double[] xData;
    private final double[] yData;
    private final int degree;
    private double[] coefficients;

    public PolinomialRegression(double[] xData, double[] yData, int degree) {
        this.xData = xData;
        this.yData = yData;
        this.degree = degree;
    }

    public void fit() {
        int N = xData.length;
        int numCoefficients = degree + 1;
        double[][] X = new double[N][numCoefficients];
        double[] Y = new double[N];

        for (int i = 0; i < N; i++) {
            double xVal = xData[i];
            Y[i] = yData[i];
            for (int j = 0; j < numCoefficients; j++) {
                X[i][j] = Math.pow(xVal, j);
            }
        }

        // Resolver el sistema de ecuaciones normales (X^T * X) * a = X^T * y
        double[][] XT = transpose(X);
        double[][] XTX = multiply(XT, X);
        double[] XTY = multiply(XT, Y);
        coefficients = solve(XTX, XTY);
    }

    private double[][] transpose(double[][] matrix) {
        int m = matrix.length;
        int n = matrix[0].length;
        double[][] transposed = new double[n][m];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                transposed[j][i] = matrix[i][j];
            }
        }
        return transposed;
    }

    private double[][] multiply(double[][] A, double[][] B) {
        int mA = A.length;
        int nA = A[0].length;
        int mB = B.length;
        int nB = B[0].length;
        double[][] C = new double[mA][nB];
        for (int i = 0; i < mA; i++) {
            for (int j = 0; j < nB; j++) {
                for (int k = 0; k < nA; k++) {
                    C[i][j] += A[i][k] * B[k][j];
                }
            }
        }
        return C;
    }

    private double[] multiply(double[][] A, double[] B) {
        int mA = A.length;
        int nA = A[0].length;
        double[] C = new double[nA];
        for (int i = 0; i < mA; i++) {
            for (int j = 0; j < nA; j++) {
                C[j] += A[i][j] * B[i];
            }
        }
        return C;
    }

    private double[] solve(double[][] A, double[] B) {
        int n = A.length;
        double[] solution = new double[n];

        for (int i = n - 1; i >= 0; i--) {
            double sum = B[i];
            for (int j = i + 1; j < n; j++) {
                sum -= A[i][j] * solution[j];
            }
            solution[i] = sum / A[i][i];
        }
        return solution;
    }

    public void printRegEquation() {
        System.out.print("Ecuación de regresión: y = ");
        for (int i = 0; i < coefficients.length; i++) {
            System.out.print(coefficients[i] + " * x^" + i);
            if (i < coefficients.length - 1) {
                System.out.print(" + ");
            }
        }
        System.out.println();
    }

    public void predict(double x) {
        double y = 0;
        for (int i = 0; i < coefficients.length; i++) {
            y += coefficients[i] * Math.pow(x, i);
        }
        System.out.println("Predicción para x = " + x + " es y = " + y);
    }
}
